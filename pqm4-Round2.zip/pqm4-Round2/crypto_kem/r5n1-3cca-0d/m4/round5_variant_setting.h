//  round5_variant_setting.h
//  Copyright (c) 2019, PQShield Ltd. and Koninklijke Philips N.V.

//  This file can be used define the variant (e.g. just #define R5ND_1KEM_0d).
#define R5N1_3CCA_0d
